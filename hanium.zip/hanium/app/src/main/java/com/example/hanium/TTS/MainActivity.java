package com.example.hanium.TTS;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hanium.R;
import com.example.hanium.TTS.GetSentenceTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    /**
     * Made By LSC
     */
    private final String TAG = "[MyLog]";
    Button ttspeech, repeat;
    TextView txtRead;
    private TextToSpeech tts;
    private boolean isAvailableToTTS = false;
    private ArrayList<Sentence> sentences;
    private int nowIndex = 0;

    /**
     * FiNISH
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txtRead = (TextView) findViewById(R.id.txtRead);

        /**
         * Made By LSC
         */
        sentences = new ArrayList<>();
        try {
            String result = new GetSentenceTask(this, "http://165.229.250.25:8080/haneum/index.php").execute().get();
            try {
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("result");
                for (int i = 0; i < jsonArray.length(); i++) {
                    sentences.add(new Sentence(jsonArray.getJSONObject(i).getString("eng"), jsonArray.getJSONObject(i).getString("kor")));
                    //Log.d(TAG, "onPostExecute: " + jsonArray.getJSONObject(i).getString("sen"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        /**
         * FiNISH
         */

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int isAvailable) {
                if (isAvailable == TextToSpeech.SUCCESS) {
                    int language = tts.setLanguage(Locale.ENGLISH);
                    if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(MainActivity.this, "지원되지 않는 언어입니다.", Toast.LENGTH_SHORT).show();
                        isAvailableToTTS = false;
                    } else {
                        isAvailableToTTS = true;
                    }
                }
            }
        });


        ttspeech = (Button) findViewById(R.id.ttspeech);

        ttspeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                speech();
            }
        });
        repeat = findViewById(R.id.repeat);
        repeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nowIndex != 0) {
                    nowIndex--;
                }
                speech();
            }
        });


    }

    public void speech() {
        if (isAvailableToTTS) {
            String text = sentences.get(nowIndex).getEng();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            txtRead.setText(sentences.get(nowIndex).getEng());
            nowIndex++;
        }

    }


}
